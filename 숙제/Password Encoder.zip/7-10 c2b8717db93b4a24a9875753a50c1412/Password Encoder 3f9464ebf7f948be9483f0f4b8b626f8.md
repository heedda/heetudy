# Password Encoder

[`https://st-lab.tistory.com/100`](https://st-lab.tistory.com/100)

비밀번호를 안전하게 저장할 수 있도록 하는 비밀번호의 단방향 암호화를 지원하는 인터페이스다.

개발 할 때는 정보가 중요하다. 그래서 그 정보를 지키려고 Password Encoder를 하는 것이다.

```java
public interface PassswordEncoder{
	//비밀번호 단방향 암기화
	String encode(CharSequence rawPasword);
	

	//암호화 되지 않은 비밀번호(raw~)와 암호화된 비밀번호(encoded~)가 일치하는지 확인
	boolean matches(CharSequence rawPassword, String encodedPassword);

	//암호화된 비밀번호를 다시 암호화하고자 할 경우 true를 return하게 설정
	default boolean UpgradeEncoding(String encodedPassword){
		return false;
	};
}
```

String Security에서 공식 지원하는 클래스

- BcryptPasswordEncoder : `BCrypt`
- Argon2PasswordEncoder : `Argon2`
- Pbkdf2PasswordEncoder : `PBKDF2`
- SCryptPasswordEncoder : `SCrypt`

4개 다 해시함수를 사용해 비밀번호를 암호화한다.

4개의 PasswordEncoder들은 Password를 Encode할 때 매번 다른 임의 salt를 생성해서 encode한다.

다음은 BcryptPasswordEncoder의 코드이다.

```java
/*
* BCryptPasswordEncoder.encode() : 암호화
*/
public String encode(CharSequence rawPassword) {

　　if (rawPassword == null) {
　　　　throw new IllegalArgumentException("rawPassword cannot be null");
　　}
	
　　String salt;
　　
   if (random != null) {
   　　salt = BCrypt.gensalt(version.getVersion(), strength, random);
   } else {
   　　salt = BCrypt.gensalt(version.getVersion(), strength);
   }
   return BCrypt.hashpw(rawPassword.toString(), salt);
}

/**
* BCrypt.gensalt() : Salt 생성
*/
public static String gensalt(String prefix, int log_rounds, SecureRandom random) throws IllegalArgumentException {

　StringBuilder rs = new StringBuilder();
　byte rnd[] = new byte[BCRYPT_SALT_LEN]; // 16byte(128bit) 크기의 Salt 생성

  if (!prefix.startsWith("$2") || (prefix.charAt(2) != 'a' && prefix.charAt(2) != 'y' && prefix.charAt(2) != 'b')) {
      throw new IllegalArgumentException ("Invalid prefix");
  }
  
  if (log_rounds < 4 || log_rounds > 31) {
      throw new IllegalArgumentException ("Invalid log_rounds");
  }

　random.nextBytes(rnd);

　rs.append("$2");
　rs.append(prefix.charAt(2));
　rs.append("$");
　if (log_rounds < 10)
      rs.append("0");
  
  rs.append(log_rounds);
  rs.append("$");
  encode_base64(rnd, rnd.length, rs);

  return rs.toString();
}
```

비밀번호 시스템에는 두가지의 종류가 있다.

먼저 해싱과 암호화이다. 이 둘의 차이는 방향에 있다. 단방향 암호화는 해싱이라고 하고 양방향 암호화를 암호화라고 한다…음… 내가 써놓고도 이상한데 그냥 양방향은 암호화, 단방향은 해싱이다.

### 단방향 해시 함수**( One-Way Hash Function )**

단방향 해시 함수는 어떤 수학적 연산(또는 알고리즘)에 의해 원본 데이터를 매핑시켜 완전히 다른 암호화된 데이터로 변환시키는 것을 의미한다. 이 변환을 해시라고 하고, 해시에 의해 암호화된 데이터를 **다이제스트(digest)**라고 한다.

말 그대로 해시는 단방향이라서 원본을 찾을 수 없다.

비밀번호 123456을 예시로 들겠다.

![img1.daumcdn.png](Password%20Encoder%203f9464ebf7f948be9483f0f4b8b626f8/img1.daumcdn.png)

즉 원본 메시지 123456 을 해시 함수에 돌려서 다이제스트인 fs32a3xzz0 을 생성하고 해당 데이터를 DB 에 저장하는 것이다.

하지만 단방향에도 단점이 존재하는데 123456에 대한 다이제스트는 항상 같다는 것이다. 즉 값이 변하지 않는다.

그래서 이를 보안하기 위해서 123456을 돌린 다이제스트를 한 번 더 돌리는 것이다. 돌리는 횟수는 상관이 없다.

일단 솔트라는 것을 알아보자
솔트란 해시함수를 돌리기 전에 원문에 임의의 문자열을 덧붙이는 것을 말한다. 단어 뜻 그대로 원문에 임의의 문자열을 붙인다는 의미의 소금친다(salting) 는 것이다.

여러번 돌리더라도 결국 몇 번 돌렸는지 횟수만 알면 상징성 있는 대표 문자열들을 추려서 대입해보면 적어도 공격하는 입장에서는 조금이나마 찾는데 시간을 줄이고, 각 횟수별 다이제스트가 Rainbow table 에 있을 확률이 높기 때문이다. 또한 같은 비밀번호를 사용하는 사용자들이 있다면 하나의 결과를 갖고도 다수 사용자의 password 를 알아내는 것이나 마찬가지다. 이를 방지하기 위해 도입한 것이 바로 솔트다

![img1.daumcdn.png](Password%20Encoder%203f9464ebf7f948be9483f0f4b8b626f8/img1.daumcdn%201.png)

그래서 사용자마다 다른 솔트를 사용하면 같은 비밀번호더라도 값이 다를 것이다. 이렇게 하면 공격하는 사람도 정보를 얻기가 더 어려워질 것이다.

즉, 같은 패스워드를 사용하더라도 salting 된 문자열은 서로 다르기 때문에 각 사용자의 다이제스트는 서로 다른 값으로 저장될 것이다.

위에 두가지 방법을 혼용해서 사용하면 더 보안이 강화 될 것이다.

![img1.daumcdn.png](Password%20Encoder%203f9464ebf7f948be9483f0f4b8b626f8/img1.daumcdn%202.png)

[구현](Password%20Encoder%203f9464ebf7f948be9483f0f4b8b626f8/%E1%84%80%E1%85%AE%E1%84%92%E1%85%A7%E1%86%AB%20ea221c0aa70647c2a4a381b06dc29009.md)